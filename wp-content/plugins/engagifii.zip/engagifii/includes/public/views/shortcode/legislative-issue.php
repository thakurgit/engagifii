<?php
 $obj =  new Engagifii_API();
$tags = $obj->legislationTagsFilter();
$options = get_option( 'ebt_api_settings' );
 $lbt_visib_legislative_list   = $options['lbt_visib_legislative_list']  ?? array();

 if(site_url() == 'https://engagifiiweb.com'){
  $legislative_tags_list             = $options['legislative_tags_list'] ?? array();

    foreach ($tags as $tag) {
      if($tag->count > 0){
        if(!in_array($tag->tagId, $legislative_tags_list)){
            array_push($legislative_tags_list, (string)$tag->tagId);
            array_push($lbt_visib_legislative_list, (string)$tag->tagId);
        }
      }
    }

    global $wpdb;
    $prepared_query = $wpdb->prepare("SELECT option_value FROM ".$wpdb->prefix."options WHERE option_name = 'ebt_api_settings' ");
    $results = $wpdb->get_results( $prepared_query );
    $option_value = $results[0]->option_value;
    $decode_option_value = unserialize($option_value);
    if(count($legislative_tags_list) > count($decode_option_value['legislative_tags_list'])){
        $decode_option_value['legislative_tags_list'] = $legislative_tags_list;
        $decode_option_value['lbt_visib_legislative_list'] = $lbt_visib_legislative_list;
        update_option('ebt_api_settings', $decode_option_value);
    }


}

function sort_associative_array($a, $b) {
    return strcmp(ucfirst(trim($a->text)), ucfirst(trim($b->text)));
}

usort($tags, "sort_associative_array");

?>

 <div class=" mb-4 mb-md-0">
  <div class="row">
      <div class="col-sm-12">
        <select class="form-control eq-height legis-issues" size="5" name="issue_tags">

   <?php foreach($tags as $tag){
          if(in_array($tag->tagId, $lbt_visib_legislative_list)){
				if($tag->count>0){
					$cevent = 'onclick="filterIssues('.$tag->tagId.')"';
				} else {
					$cevent = 'disabled';
				}
        ?>
        <option class="text-break pb-1" data-title="<?php echo base64_encode($tag->text);?>" data-id="<?php echo $tag->tagId;?>" <?php echo $cevent; ?>>
        
        <?php  

         echo $tag->text.' ('.$tag->count.')';
      ?>
        </option>
        <?php //}
		 } }?>
    </select>
    </div>
    </div>
  </div>

  <script type="text/javascript">
	var sessionId='';
  var allissues = <?php echo json_encode( $lbt_visib_legislative_list);  ?>;
  function toNumber1(value) {
	 return Number(value);
		}
  allissues  = allissues.map(toNumber1);
	optionhover();
	$('.session-tab li button').click(function(){
		$('<div class="d-flex justify-content-center issue-loader position-absolute w-100 h-100 align-items-center" style="background:rgba(255,255,255,0.6);"><div class="spinner-grow text-primary" role="status"> <span class="sr-only">Loading...</span></div></div>').insertBefore(".legis-issues"); 
		sessionId = $(this).attr('id');
		getLegislativeIssues();
		localStorage.setItem("sessionname", $(this).attr('sessionname'));
	});
	
function getLegislativeIssues()
{
  $.ajax({
      type : "post",
      url: engagifiiUrl_ajaxurl,
      data:{
		sessionId : sessionId,
        action:'legislativeissuedata'
      },
      success: function(response) {    
	  		var data = response.api_response;
			data = JSON.parse(data);
			var html='';
			$.each(data, function(i, item) {
				if($.inArray(item.tagId, allissues) != -1) {
				if(item.count>0){
					var cevent = 'onclick="filterIssues('+item.tagId+')"';
				}else {
					var cevent = 'disabled';
				}
				 html +=' <option class="text-break pb-1" data-title="'+btoa(item.text)+'" data-id="'+item.tagId+'" '+cevent+'>'+item.text+' ('+item.count+')';
				}
			});			
			
        	$('.legis-issues').html(html);
			$('.legis-issues').siblings('.issue-loader').remove();
			optionhover();
            
         }
    });
}	


    function filterIssues(id) {
      $("body").removeClass('loaded');
     var tag = $('select[name="issue_tags"]').find(':selected').data('title');
	 if(sessionId==''){
      var redirect_url = '<?php echo get_site_url(); ?>/bill-tracking/?tag='+id+'&'+tag;
	 } else {
      var redirect_url = '<?php echo get_site_url(); ?>/bill-tracking/?tag='+id+'&'+tag+'&sessionId='+sessionId;
	 }
      window.location.href= redirect_url;

    }
	function optionhover(){
	 $('option[onclick]').mouseover(function(){
     $(this).addClass('bg-secondary');
});
$('option[onclick]').mouseout(function(){
     $(this).removeClass('bg-secondary');
});
	}
</script>