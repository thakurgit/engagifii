
$(document).ready(function(){
    //$( "#ebtmaintable" ).wrap( "<div class='engaifii-scroller'></div>" );
      // Add class name & Name Attribute in top search section
    
    $(".versionPanel").hide();
    $(".documentPanel").hide();
    
    // Show Hide Functionality
    $("#summary").click(function(){
        $(".versionPanel").hide();
        $(".documentPanel").hide();
        $(".summaryPanel").show();
        $('#summary').addClass('active');
        $('#document').removeClass('active');
        $('#version').removeClass('active');
        
        
    });
    $("#version").click(function(){
        $(".summaryPanel").hide();
        $(".documentPanel").hide();
        $(".versionPanel").show();
        $('#version').addClass('active');
        $('#summary').removeClass('active');
        $('#document').removeClass('active');
    });

    $("#document").click(function(){
        $(".summaryPanel").hide();
        $(".versionPanel").hide();
        $(".documentPanel").show();
        $('#document').addClass('active');
        $('#summary').removeClass('active');
        
        $('#version').removeClass('active');
        
        
    });



        var p = document.location.pathname;
        if(p == '/accg/engagifii-detail/')
        {
            $(".staffanalysisPanel").show();
            $(".summaryPanel").hide();
        }
        else{ 
            $(".staffanalysisPanel").hide();
            $(".summaryPanel").show();
        }

        
        $(".versionsPanel").hide();
        $(".votesPanel").hide();
        $(".historyPanel").hide();
        $(".quickPanel").hide();
        

    // Show Hide Functionality
    $("#summary").click(function(){
        $(".versionsPanel").hide();
        $(".votesPanel").hide();
        $(".historyPanel").hide();
        $(".quickPanel").hide();
        $(".staffanalysisPanel").hide();
        $(".summaryPanel").show();
        $('.lbt-link').removeClass('active');
        $('#summary').addClass("active");
        
    });


    $("#staffanalysis").click(function(){
        $(".summaryPanel").hide();
        $(".versionsPanel").hide();
        $(".votesPanel").hide();
        $(".historyPanel").hide();
        $(".quickPanel").hide();
        $(".staffanalysisPanel").show();
        $('.lbt-link').removeClass('active');
        $('#staff').addClass("active");
    });

    $("#versions").click(function(){
        $(".summaryPanel").hide();
        $(".votesPanel").hide();
        $(".historyPanel").hide();
        $(".quickPanel").hide();
        $(".staffanalysisPanel").hide();
        $(".versionsPanel").show();
        $('.lbt-link').removeClass('active');
        $('#versions').addClass("active");
        
    });

    $("#votes").click(function(){
        $(".summaryPanel").hide();
        $(".versionsPanel").hide();
        $(".historyPanel").hide();
        $(".quickPanel").hide();
        $(".staffanalysisPanel").hide();
        $(".votesPanel").show();
        $('.lbt-link').removeClass('active');
        $('#votes').addClass("active");
        
    });


    $("#history").click(function(){
        $(".summaryPanel").hide();
        $(".versionsPanel").hide();
        $(".votesPanel").hide();
        $(".quickPanel").hide();
        $(".staffanalysisPanel").hide();
        $(".historyPanel").show();
        $('.lbt-link').removeClass('active');
        $('#history').addClass("active");
        
    });

    $("#quick").click(function(){
        $(".summaryPanel").hide();
        $(".versionsPanel").hide();
        $(".votesPanel").hide();
        $(".historyPanel").hide();
        $(".staffanalysisPanel").hide();
        $(".quickPanel").show();
        $('.lbt-link').removeClass('active');
        $('#quick').addClass("active");
        
    });
    

   

});

    function __addExtraDiv(title)
    {
      var span_Ext = $(document).find(".select2-search").find("h6.engwarpper").length;
      if(span_Ext<1)
      {  
          $(document).find(".select2-search").prepend("<h6 class=\"engwarpper\"> "+title+" </h5>");
      }
    }

     
  function format(item, state) {
     
  var profilePic = ""; 
  var img = ''  ;
  var tagid = '';
  var tagname = '';
  var tag_url = '';
   if (typeof item.element !== 'undefined')   
   {
      profilePic = item.element.dataset.profilepic;
      tagid      = item.element.dataset.tagid;
      tagname    = item.element.dataset.tagtext;

  if (!item.id) {
    return item.text;
  }
   if(tagid && tagname)
    {
        var current_url = document.URL;
        tag_url = current_url+'?tag='+tagid+'&'+tagname;

    }

  img = $("<img>", {
    class: "img-flag",
    width: 26,
    src: profilePic
  });
  if(tag_url)
  {
        var span = $("<a>", {
        class: "tag-redirect",
        text: " " + item.text,
        href: tag_url
    });
  }
  else
  {
        var span = $("<p>", {
    text: " " + item.text
  });
  }
  
  if(profilePic)
    span.prepend(img);



  return span;
    }
}

$("[data-toggle = 'tooltip']").tooltip(); 
function dt_dropdown() {
  $('.td-dropdown').each(function() {   
$(this).mCustomScrollbar({
		 	 scrollButtons:{enable:true},
					theme:'minimal-dark',
		 			scrollbarPosition:'outside'
});
});
  $('.search-dropdown').each(function() { 
  $(this).on('keyup', function() {
    var value = $(this).val().toLowerCase();
    $(this).parent().siblings('li, a').filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
	  if($(this).parent().siblings('li:visible, a:visible').length<1){
		  $(this).parent().siblings('span').addClass('d-block').removeClass('d-none');
	  } else {
		  $(this).parent().siblings('span').addClass('d-none').removeClass('d-block');
	  }
  });
  });
   
}
function dt_scroll(){
 $('.dataTables_wrapper ').append('<span class="nxt position-absolute bg-primary text-white rounded-circle d-none d-xl-inline-flex align-items-center justify-content-center"><i class="far fa-angle-right"></i></span>');
            $('.dataTables_wrapper ').prepend('<span class="prv position-absolute bg-primary text-white rounded-circle d-none d-xl-inline-flex align-items-center justify-content-center disabled"><i class="far fa-angle-left"></i></span>');
              var divWidth = parseInt($('.custom-scroll').outerWidth());
			 var tablewidth = parseInt($('#ebtmaintable').outerWidth());
               if(tablewidth<=divWidth){
					$('.nxt,.prv').addClass('disabled').removeClass('d-xl-inline-flex');  
					$('.engagifii-main-cotainer').removeClass('px-xl-5');  
					return false;
			   } else {
				$('.nxt').click(function () {
					  // tablewidth = parseInt($('#ebtmaintable').outerWidth());
				   $('.custom-scroll').animate({
					  scrollLeft: "+=250px"
				   }, "slow",function() {
					   var scrollLeft = parseInt($('.custom-scroll').scrollLeft());
					  // console.log(tablewidth+','+divWidth+scrollLeft)
    					$('.prv').removeClass('disabled'); 
				  		 if(tablewidth==divWidth+scrollLeft||tablewidth==divWidth+scrollLeft-1||tablewidth==divWidth+scrollLeft+1){
						  $('.nxt').addClass('disabled');  
				  		 }	
						// console.log(tablewidth+'+'+divWidth+scrollLeft);
  					}); 
				   
				});  
				$('.prv').click(function () {
				   $('.custom-scroll').animate({
					  scrollLeft: "-=250px"
				   }, "slow",function(){
					 $('.nxt').removeClass('disabled');  
					 if($('.custom-scroll').scrollLeft()==0){
						$('.prv').addClass('disabled');  
					 }
				   });
				});  
			   }	
}
$(document).ready(function(){
    $('body').on('click', '.heading-title' ,function(){
        $(this).parent().toggleClass('active');
		 $(this).parent().siblings('.filter-list').removeClass('active');
    });
});